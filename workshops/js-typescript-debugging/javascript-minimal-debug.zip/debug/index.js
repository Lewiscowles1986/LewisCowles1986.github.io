const express = require('express');
const app = express();

const { DataSource } = require('typeorm');

const orm = new DataSource({
    type: 'postgres',
    host: 'localhost',
    port: 5432,
    username: "postgres",
    password: "password",
    database: "postgres",
    logging: ['error', 'query'],
});

app.get('/', async (req, res) => {
    await orm.createQueryRunner().query('SELECT NOW();');
    res.send(`Hello ${req.query.name || 'World'}!`);
});

orm.initialize().then(() => {
    app.listen(3000, () => console.info('Example app listening on port http://localhost:3000!'));
}).catch((err) => console.error('Unrecoverable error! Unable to connect to database.', err));
